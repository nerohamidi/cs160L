package edu.sdsu.cs160l.calculator;

/**
 * Do not implement/fix this class
 */
public class SimpleCalculator implements Calculator {
    @Override
    public int add(int a, int b) {
        return 0;
    }

    @Override
    public int sub(int a, int b) {
        return 0;
    }

    @Override
    public int div(int a, int b) throws ArithmeticException {
        return 0;
    }

    @Override
    public int mul(int a, int b) {
        return 0;
    }
}
