package edu.sdsu.cs160l;

/**
 * complete all TODOs in
 * {@link edu.sdsu.cs160l.assignment.StudentMetricProcessor}
 * and {@link edu.sdsu.cs160l.assignment.LambdaInitialization}
 */
public class FPMain {
    public static void main(String[] args) {

    }

}
