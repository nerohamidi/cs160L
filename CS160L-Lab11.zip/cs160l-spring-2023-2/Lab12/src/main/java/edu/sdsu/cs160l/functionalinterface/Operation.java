package edu.sdsu.cs160l.functionalinterface;

@FunctionalInterface
public interface Operation {
  int operate(int a, int b);
}
