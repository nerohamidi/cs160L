package edu.sdsu.cs160l.university.lab5.student;

public enum StudentType {
    SDSU,
    TRANSFER
}
