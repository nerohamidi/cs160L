package edu.sdsu.cs160l;

/**
 *
 *  TDD is the practice of writing scenarios first and then logic to write minimal bug free code.
 *
 *  Fix CalculatorTest.java
 *  Fix MathOperationsTest.java
 */
public class TDDMain {
    public static void main(String[] args) {
        //write sample code here
    }
}
