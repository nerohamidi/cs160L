package edu.sdsu.cs160l.assignment.institute.student;

public enum StudentLevel {
  FRESHMAN,
  SOPHOMORE,
  JUNIOR,
  SENIOR
}
