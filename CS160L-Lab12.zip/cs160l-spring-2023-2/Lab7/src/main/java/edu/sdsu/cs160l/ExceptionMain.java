package edu.sdsu.cs160l;

/**
 * Exceptions are of 2 types, Checked and Unchecked
 * They are a powerful way of knowing what if something goes wrong with our code.
 *
 * Fix 2 todos in your code
 * 1) in registrar class
 * 2) in course class
 */
public class ExceptionMain {
    public static void main(String[] args) {
        //write sample code here
    }
}
