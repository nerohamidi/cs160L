package edu.sdsu.cs160l.university.lab7.exceptions;

//TODO implement this exception as per the bluePrint in ClassFullException
public class StudentAlreadyEnrolledException extends Exception{
    public StudentAlreadyEnrolledException(String message) {
        super(message);
    }
}
