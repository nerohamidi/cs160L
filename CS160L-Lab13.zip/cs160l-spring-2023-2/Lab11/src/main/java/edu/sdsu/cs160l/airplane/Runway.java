package edu.sdsu.cs160l.airplane;

import edu.sdsu.cs160l.airplane.Airplane;

public class Runway {
    public static void main(String[] args) throws Exception {
        Airplane a = new Airplane();
        a.start();
    }
}
