package edu.sdsu.cs160l.assignment.institute.student;

public enum StudentMajor {
  COMPUTER_SCIENCE,
  COMPUTER_ENGINEERING,
  BIOLOGY,
  MATH,
  PHYSICS
}
