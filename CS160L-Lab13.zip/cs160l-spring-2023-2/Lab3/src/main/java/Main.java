
/**
 *  This lab will introduce you to unit testing and refresh your memory about arrays.
 *  We will spend the
 */
public class Main {
    public static void main(String[] args) {
        //To create a student
        Student aditi = new Student(825027067L, "Aditi Mewada", 3.7);

        // printing an object directly would invoke the objects toString method
        System.out.println(aditi);
    }
}
