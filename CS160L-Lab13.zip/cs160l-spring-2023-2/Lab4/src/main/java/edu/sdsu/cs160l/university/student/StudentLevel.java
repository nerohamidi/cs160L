package edu.sdsu.cs160l.university.student;

public enum StudentLevel {
        FRESHMAN,
        SOPHOMORE,
        JUNIOR,
        SENIOR
}
