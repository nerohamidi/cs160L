package edu.sdsu.cs160l.university.lab5.application;

public class ScholarshipApplication implements UniversityApplication{
    @Override
    public void submitScore(Applicant s, float score) throws RuntimeException {
        if(score < 3.2){
            throw new RuntimeException("Exception message");
        }
        s.setApplicantScore(score);
    }

    @Override
    public void submitDocuments(Applicant s, String documents) {
        s.setApplicantDocuments(documents);
    }

    @Override
    public boolean checkStatus(Applicant applicant) {
        if(applicant.getApplicantScore() >= 3.2 && applicant.getApplicantDocuments() != null){
            return true;
        }
        return false;
    }
}
