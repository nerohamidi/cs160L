package edu.sdsu.cs160l.university.student;

public enum StudentMajor {
    computersci,
    computereng,
    biology,
    math,
    politicalsci
}

