package edu.sdsu.cs160l.university.lab7.student;

public enum StudentMajor {
    computersci,
    computereng,
    biology,
    math,
    politicalsci
}

