package edu.sdsu.cs160l.university.lab7.student;

public enum StudentType {
    SDSU,
    TRANSFER
}
