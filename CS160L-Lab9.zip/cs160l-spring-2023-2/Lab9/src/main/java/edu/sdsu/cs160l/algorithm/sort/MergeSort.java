package edu.sdsu.cs160l.algorithm.sort;

import java.util.Comparator;

/**
 * TODO assignment (4 points)
 *  implement mergesort in a similar way as quick sort and bubble sort structurally
 *
 *  hint to create a generic array use T[] t = (T[])(new Object[])
 */
public class MergeSort implements Sorter {

    @Override
    @SuppressWarnings("unchecked")
    public <T> void sort(T[] c) {
        Comparable[] comparable = (Comparable[]) c;
        sort(comparable, Comparator.naturalOrder());
    }

    @Override
    public <T> void sort(T[] c, Comparator<? super T> comparisonStrategy) {
        T[] tempArr = (T[]) new Object[c.length]; //creates a new temporary array (generic array) for merge sort
        mergeSort(c, tempArr, 0, c.length - 1, comparisonStrategy); //calls mergeSort method
    }

    private <T> void mergeSort(T[] a, T[] tempArr, int left, int right, Comparator<? super T> comparison) {
        if (left < right) { //checks if the left value is less than the right value
            int center = (left + right) / 2; // calculates the middle
            mergeSort(a, tempArr, left, center, comparison); //inputs the left side in mergeSort (recursive)
            mergeSort(a, tempArr, center + 1, right, comparison); //inputs the right side in mergeSort (recurseibe)
            merge(a, tempArr, left, center + 1, right, comparison); //calls the merge method
        }
    }

    //mergeSort is a divide and conquer algo.
    //it breaks up an array into two halves
    //and then breaks that into two halves until each element is seperated
    //the program then works backwards to merge each of the elements and clusters together so that they are ranked

    private <T> void merge(T[] a, T[] tempArr, int leftPos, int rightPos, int rightEnd, Comparator<? super T> comparison) {
        int leftEnd = rightPos - 1;
        int tempArrPos = leftPos; //set index at left pos
        int numElements = rightEnd - leftPos + 1; //set range
        //sort each subarray using this sorting algo.
        while (leftPos <= leftEnd && rightPos <= rightEnd) {
            if (comparison.compare(a[leftPos], a[rightPos]) <= 0) {  //compares right and left positions
                tempArr[tempArrPos++] = a[leftPos++]; //if less, put the value on right
                //also increment using the ++ after the index
            } else {
                tempArr[tempArrPos++] = a[rightPos++]; //if more, put the value on left
            }
        }

        while (leftPos <= leftEnd) { //copies left elements onto tempArr array
            tempArr[tempArrPos++] = a[leftPos++];
        }

        while (rightPos <= rightEnd) { //copies left elements onto tempArr array
            tempArr[tempArrPos++] = a[rightPos++];
        }

        for (int i = 0; i < numElements; i++, rightEnd--) {  //copies the tempArr arr into a[] starting from right
            a[rightEnd] = tempArr[rightEnd];
        }
    }
}

