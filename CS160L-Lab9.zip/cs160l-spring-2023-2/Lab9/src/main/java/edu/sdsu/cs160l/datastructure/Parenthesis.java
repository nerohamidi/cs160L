package edu.sdsu.cs160l.datastructure;

import java.util.Stack;

// TODO implement the below function (2 points)
//  use Test Class to test your implementation
public class Parenthesis {
    /**
     * @param brackets contains a sequence of Characters '(' or ')'
     *                 eg : '((()))' is valid
     *                 '())' is invalid
     *                 ')(' is invalid
     *                 Check the test class for more examples
     * @return true is the brackets are balanced else false
     */
    public boolean isBalanced(String brackets) {
        Stack<Character> stack = new Stack<>(); //creates new stack
        for (int i = 0; i < brackets.length(); i++) {
            char c = brackets.charAt(i); //creates variable for current character at a certain index
            if (c == '(') { //checks if the character is "("
                stack.push(c); //if it is it pushes it on to the stack
            } else if (c == ')') { //if it's not, it checks if the character is ")"
                if (stack.isEmpty()) { //if the stack is empty after this, return false
                    return false;
                }
                stack.pop(); //pop the first value of the stack off if the stack is not empty
            } else {
                // ignore other characters
            }
        }
        return stack.isEmpty(); //after popping all the correct character positions, if it is not empty that means
        //that the string is imbalanced and thus false should be returned (vice versa for when it's correct)
    }
}
