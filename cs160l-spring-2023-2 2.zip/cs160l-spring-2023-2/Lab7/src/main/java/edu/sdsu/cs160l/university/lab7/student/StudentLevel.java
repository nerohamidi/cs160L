package edu.sdsu.cs160l.university.lab7.student;

public enum StudentLevel {
        FRESHMAN,
        SOPHOMORE,
        JUNIOR,
        SENIOR
}
