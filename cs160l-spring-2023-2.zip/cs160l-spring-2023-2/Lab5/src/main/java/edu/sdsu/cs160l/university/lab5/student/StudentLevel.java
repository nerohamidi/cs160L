package edu.sdsu.cs160l.university.lab5.student;

public enum StudentLevel {
        FRESHMAN,
        SOPHOMORE,
        JUNIOR,
        SENIOR
}
