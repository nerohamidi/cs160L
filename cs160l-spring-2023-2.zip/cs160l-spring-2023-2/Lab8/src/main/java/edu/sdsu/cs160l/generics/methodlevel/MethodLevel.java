package edu.sdsu.cs160l.generics.methodlevel;

public interface MethodLevel {
    <T> void print(T t);
}
