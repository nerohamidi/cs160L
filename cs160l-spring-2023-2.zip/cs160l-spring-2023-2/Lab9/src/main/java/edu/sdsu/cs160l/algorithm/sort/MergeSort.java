package edu.sdsu.cs160l.algorithm.sort;

import java.util.Comparator;

/**
 * TODO assignment (4 points)
 *  implement mergesort in a similar way as quick sort and bubble sort structurally
 *
 *  hint to create a generic array use T[] t = (T[])(new Object[])
 */
public class MergeSort implements Sorter {

    @Override
    @SuppressWarnings("unchecked")
    public <T> void sort(T[] c) {
        Comparable[] comparable = (Comparable[]) c;
        sort(comparable, Comparator.naturalOrder());
    }

    @Override
    public <T> void sort(T[] c, Comparator<? super T> comparisonStrategy) {
        T[] workspace = (T[]) new Object[c.length]; //creates a new workspace for merge sort
        mergeSort(c, workspace, 0, c.length - 1, comparisonStrategy); //calls mergeSort method
    }

    private <T> void mergeSort(T[] a, T[] workspace, int left, int right, Comparator<? super T> comparisonStrategy) {
        if (left < right) { //checks if the left and right position makes sense logically
            int center = (left + right) / 2; // calculates the middle
            mergeSort(a, workspace, left, center, comparisonStrategy); //inputs the left side in mergeSort (recursive)
            mergeSort(a, workspace, center + 1, right, comparisonStrategy); //inputs the right side in mergeSort (recurseibe)
            merge(a, workspace, left, center + 1, right, comparisonStrategy); //calls the merge method
        }
    }

    private <T> void merge(T[] a, T[] workspace, int leftPos, int rightPos, int rightEnd, Comparator<? super T> comparisonStrategy) {
        int leftEnd = rightPos - 1;
        int workspacePos = leftPos;
        int numElements = rightEnd - leftPos + 1;
        //sort each subarray using this sorting algo.
        while (leftPos <= leftEnd && rightPos <= rightEnd) {
            if (comparisonStrategy.compare(a[leftPos], a[rightPos]) <= 0) {  //compares right and left positions
                workspace[workspacePos++] = a[leftPos++]; //if less makes the left position the next value
            } else {
                workspace[workspacePos++] = a[rightPos++]; //if right it makes the right position the next value
            }
        }

        while (leftPos <= leftEnd) {
            workspace[workspacePos++] = a[leftPos++];
        }

        while (rightPos <= rightEnd) {
            workspace[workspacePos++] = a[rightPos++];
        }

        for (int i = 0; i < numElements; i++, rightEnd--) {
            a[rightEnd] = workspace[rightEnd];
        }
    }
}

