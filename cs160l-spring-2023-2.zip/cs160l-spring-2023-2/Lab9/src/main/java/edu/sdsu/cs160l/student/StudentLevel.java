package edu.sdsu.cs160l.student;

public enum StudentLevel {
    FRESHMAN,
    SOPHOMORE,
    JUNIOR,
    SENIOR
}
